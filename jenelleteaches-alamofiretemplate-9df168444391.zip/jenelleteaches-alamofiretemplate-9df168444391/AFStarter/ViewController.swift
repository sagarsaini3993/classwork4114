//
//  ViewController.swift
//  AFStarter
//
//  Created by parrot on 2018-11-13.
//  Copyright © 2018 room1. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class ViewController: UIViewController {

    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var conditionsLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var rainChanceLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var lastUpdatedLabel: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func weatherButtonPressed(_ sender: UIButton) {
        print("button pressed")
        
        // 1. Go to the URL
        let URL = "https://api.darksky.net/forecast/c19cfa2911876f15cd95bc6b262a7874/43.6532,-79.3832?units=ca"
        Alamofire.request(URL, method: .get, parameters: nil).responseJSON { (response) in
            if response.result.isSuccess {
                print("I got something from the weather website")
                print("Response from website:")
                print("=========================")
                print(response.data!)
                
                do {
                    let json = try JSON(data: response.data!)
//                    print(json)
                    print(json["latitude"])
                    print(json["longitude"])
                    print(json["currently"]["temperature"])
                    
                    
                    self.tempLabel.text = json["currently"]["temperature"].string
                    self.conditionsLabel.text = json["currently"]["summary"].string
                    self.rainChanceLabel.text = json["currently"]["precipProbability"].string
                    self.windSpeedLabel.text = json["currently"]["windSpeed"].string
                    self.humidityLabel.text = json["currently"]["humidity"].string
                    
                    let date = Date(timeIntervalSince1970: 1542382811)
                    let dateFormatter = DateFormatter()
                    dateFormatter.timeStyle = DateFormatter.Style.medium //Set time style
//                    dateFormatter.dateStyle = DateFormatter.Style.medium //Set date style
                    let localDate = dateFormatter.string(from: date)
                    print(localDate)
                    
                    self.lastUpdatedLabel.text = localDate
                    
                    
                    
                    
                } catch {
                    print("Error getting data from website")
                }
            } else {
                print("Error getting data from website")
            }
        }
        
        // 2. Get data from the website
        
        // 3. Parse the data you need
        
        // 4. Do something with the data
    }
    
}

